# Pytorch 中文手册第四章 ： 提高

## 目录

## 第一节 Fine-tuning

[Fine-tuning](4.1-fine-tuning.ipynb)

## 第二节 可视化

[visdom](4.2.1-visdom.ipynb)

[tensorboardx](4.2.2-tensorboardx.ipynb)

[可视化理解卷积神经网络](4.2.2-tensorboardx.ipynb)